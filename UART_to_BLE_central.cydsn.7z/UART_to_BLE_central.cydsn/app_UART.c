/*******************************************************************************
* File Name: app_UART.c
*
* Description:
*  Common BLE application code for client devices.
*
*******************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "app_UART.h"
#include "project.h"

const uint8 flash_storage[16] = {0};

void StoreInFlash(uint8 *newData, uint8 length)
{
    /* make sure the BLE stack is not in low-power mode */
    CyBle_ExitLPM();

    /* repeat flash write attempt until success */


        /* write segment of configuration structure from RAM into flash */
        CYBLE_API_RESULT_T result = CyBle_StoreAppData(
            newData,                    /* uint8 pointer to source data */
            (uint8_t *)&flash_storage,  /* uint8 pointer to const destination */
            length,                     /* number of bytes to write */
            0);                         /* don't force write, but loop will keep retrying */

}
/*******************************************************************************
* Function Name: HandleUartRxTraffic
********************************************************************************
*
* Summary:
*  This function takes data from received notfications and pushes it to the 
*  UART TX buffer. 
*
* Parameters:
*  CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T * - the notification parameter as  
*                                           recieved by the BLE stack
*
* Return:
*   None.
*
*******************************************************************************/
void HandleUartRxTraffic(CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T *uartRxDataNotification)
{
    if(uartRxDataNotification->handleValPair.attrHandle == txCharHandle)
    {
        UART_SpiUartPutArray(uartRxDataNotification->handleValPair.value.val, \
            (uint32) uartRxDataNotification->handleValPair.value.len);
    }
   
}


/*******************************************************************************
* Function Name: HandleUartTxTraffic
********************************************************************************
*
* Summary:
*  This function takes data from UART RX buffer and pushes it to the server 
*  as Write Without Response command.
*
* Parameters:
*  None.
*
* Return:
*   None.
*
*******************************************************************************/
uint8	WriteArray[15];		
uint8	WriteArray2[16];	
uint8	ReadArray[7];	
uint8   temp[7];

/* constant variable container, will be stored in flash */



void HandleUartTxTraffic(void)
{
    int k;
	//	Fill Array with values
    WriteArray[0] = (uint8) 0x52;
    WriteArray[1] = (uint8) 0x65;
    WriteArray[2] = (uint8) 0x64;
    WriteArray[3] = (uint8) 0x42;
    WriteArray[4] = (uint8) 0x65;
    WriteArray[5] = (uint8) 0x61;
    WriteArray[6] = (uint8) 0x72;
    WriteArray[7] = (uint8) 0x2c;
    WriteArray[8] = (uint8) 0x31;
    WriteArray[9] = (uint8) 0x32;
    WriteArray[10] = (uint8) 0x33;
    WriteArray[11] = (uint8) 0x34;
    WriteArray[12] = (uint8) 0x35;
    WriteArray[13] = (uint8) 0x36;
    WriteArray[14] = (uint8) 0x25;

    
    StoreInFlash(WriteArray, 15);

    memcpy(WriteArray2, flash_storage, 16);

    uint8   index;
    uint8   uartTxData[mtuSize];
    uint16  uartTxDataLength;	
    CYBLE_API_RESULT_T              bleApiResult;
    CYBLE_GATTC_WRITE_CMD_REQ_T     uartTxDataWriteCmd;

    uartTxDataWriteCmd.value.len  = (uint32)20;
    uartTxDataWriteCmd.attrHandle = rxCharHandle;
    uartTxDataWriteCmd.value.val  = WriteArray2;          

    bleApiResult = CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &uartTxDataWriteCmd);
    CyBle_ProcessEvents();

    

            
}




/*****************************************************************************************
* Function Name: DisableUartRxInt
******************************************************************************************
*
* Summary:
*  This function disables the UART RX interrupt.
*
* Parameters:
*   None.
*
* Return:
*   None.
*
*****************************************************************************************/
void DisableUartRxInt(void)
{
    UART_INTR_RX_MASK_REG &= ~UART_RX_INTR_MASK;  
}

/*****************************************************************************************
* Function Name: EnableUartRxInt
******************************************************************************************
*
* Summary:
*  This function enables the UART RX interrupt.
*
* Parameters:
*   None.
*
* Return:
*   None.
*
*****************************************************************************************/
void EnableUartRxInt(void)
{
    UART_INTR_RX_MASK_REG |= UART_RX_INTR_MASK;  
}

/* [] END OF FILE */
