//***********************************************************************************//
//*	Project:	PSoC4 BLE Access to the FRam										*//
//*																					*//
//*	File:		FRam.c			 													*//
//*	Version:	1.0																	*//
//*																					*//
//*	Author:		Bob Marlowe															*//
//*	(C) 2014	Jörg Meier Software - Entwicklung briefe@jmeiersoftware.de			*//
//***********************************************************************************//
//***********************************************************************************//
//*																					*//
//*		Principles of Operation														*//
//*		Simply accessing the FM2010 on the Pioneer BLE board using 					*//
//*		the I2C interface															*//
//*																					*//
//*		The function SelectHiClock switches the FRam to max 1MByte/s transfer rate	*//
//*		and the ClockHiLO to 16MHz.													*//
//*		After a successful transmition (FRam_Read or Write) the clock is switched	*//
//*		back to normal 6.4MHz resulting in 400kByte/s								*//
//*																					*//
//***********************************************************************************//

//***********************************************************************************//
//**************** Libraries ********************************************************//
//***********************************************************************************//
#include <FRam.h>

//***********************************************************************************//
//**************** Definitions and Macros *******************************************//
//***********************************************************************************//
//	None yet

//***********************************************************************************//
//******************* Structs, Typedefs and Enums ***********************************//
//***********************************************************************************//
//	None yet

//***********************************************************************************//
//******************* Data Area *****************************************************//
//***********************************************************************************//
static uint16 LowerAddress;
static uint8 I2CAddress;

//***********************************************************************************//
//****************** Prototypes *****************************************************//
//***********************************************************************************//
static uint32 SetFramAddress(void *FRamAddress);

//***********************************************************************************//
//****************** Program Area ***************************************************//
//***********************************************************************************//
void FRam_Start(void)														//	Start all needed components
{
	Clock_HiLo_Start();
	FRamInterface_Start();
}
//**********************************************************************

uint32 FRam_Write(uint8 * Data, void * FRamAddress, uint16 Count)			//	Write to FRam
{
uint32	Result;
uint16	ii = 0;
	
	if((Result = SetFramAddress(FRamAddress))) return Result;
	
	while(ii++ < Count)
	{
		Result = FRamInterface_I2CMasterWriteByte((uint32)(*(Data + ii)),1000);
		if(Result) return Result;
	}
	Result = FRamInterface_I2CMasterSendStop(1000);
	Clock_HiLo_SetFractionalDividerRegister(6,167);
	return Result;
}
//**********************************************************************

uint32 FRam_Read (uint8 * Destination, void * FRamAddress, uint16 Count)	//	Read from FRam
{
uint32	Result;
uint16	ii = 0;
	
	if((Result = SetFramAddress(FRamAddress))) return Result;
	
	Result = FRamInterface_I2CMasterSendRestart(I2CAddress,SetFramAddress(FRamAddress),1000);
	if(Result) return Result;

	while(ii++ < Count)
	{
		*(Destination++)= FRamInterface_I2CMasterReadByte(ii < (Count)?FRamInterface_I2C_ACK_DATA:FRamInterface_I2C_NAK_DATA,SetFramAddress(FRamAddress),1000);
	}
	Result = FRamInterface_I2CMasterSendStop(1000);
	Clock_HiLo_SetFractionalDividerRegister(6,16);
	return Result;
}
//**********************************************************************

void FRam_Stop(void)														//	Stop all used components
{
	FRamInterface_Stop();
	Clock_HiLo_Stop();
}
//**********************************************************************

void FRam_SelectHiClock(void)
{
	FRamInterface_I2CMasterSendStart(FRamHsModeCmd,FRamInterface_I2C_READ_XFER_MODE,1000);
	Clock_HiLo_SetFractionalDividerRegister(2,0);
}
//**********************************************************************

static uint32 SetFramAddress(void *FRamAddress)								//	Switch to 1MByte/s transfer speed
{
uint32 Result;	
	I2CAddress = FRamI2CAddress;
	if((uint32)FRamAddress & 0x1ul << 16) I2CAddress |= 0x01;				//	Isolate Address-bit 16
	LowerAddress = LO16((uint16)((uint32)FRamAddress));						//	and insert it into slave address

	Result = FRamInterface_I2CMasterSendStart(I2CAddress,FRamInterface_I2C_WRITE_XFER_MODE,1000);
	if(Result) return Result;
	Result = FRamInterface_I2CMasterWriteByte((uint32)((LowerAddress >> 8) & 0x000000ff),1000);
	if(Result) return Result;
	Result = FRamInterface_I2CMasterWriteByte((uint32)(LowerAddress &  0x000000ff),1000);
	return Result;
}
//**********************************************************************


/* [] END OF FILE */
