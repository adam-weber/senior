/*******************************************************************************
* File Name: app_UART.c
*
* Description:
*  Common BLE application code for client devices.
*
*******************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "app_UART.h"
#include "project.h"
#include "FRam.h"
#define ArraySize			6000
/*******************************************************************************
* Function Name: HandleUartRxTraffic
********************************************************************************
*
* Summary:
*  This function takes data from received notfications and pushes it to the 
*  UART TX buffer. 
*
* Parameters:
*  CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T * - the notification parameter as  
*                                           recieved by the BLE stack
*
* Return:
*   None.
*
*******************************************************************************/
void HandleUartRxTraffic(CYBLE_GATTC_HANDLE_VALUE_NTF_PARAM_T *uartRxDataNotification)
{
    if(uartRxDataNotification->handleValPair.attrHandle == txCharHandle)
    {
        UART_SpiUartPutArray(uartRxDataNotification->handleValPair.value.val, \
            (uint32) uartRxDataNotification->handleValPair.value.len);
    }
   
}


/*******************************************************************************
* Function Name: HandleUartTxTraffic
********************************************************************************
*
* Summary:
*  This function takes data from UART RX buffer and pushes it to the server 
*  as Write Without Response command.
*
* Parameters:
*  None.
*
* Return:
*   None.
*
*******************************************************************************/
uint8	WriteArray[ArraySize];							
uint8	ReadArray[ArraySize];	

void HandleUartTxTraffic(void)
{
    int k;
	for(k = 0; k < ArraySize; k++)
	{
		WriteArray[k] = (uint8) "A";					//	Fill Array with values
	}

    FRam_SelectHiClock();
    FRam_Write(WriteArray,0,ArraySize);
    FRam_Read(ReadArray,0,ArraySize);

    uint8   index;
    uint8   uartTxData[mtuSize];
    uint16  uartTxDataLength;
    char str[7];
    for(k=0; k<7; k++){
        str[k] = ("\"",ReadArray[k], "\"");
    }
    char str2[7] = {"jesus"};
    static uint16 uartIdleCount = UART_IDLE_TIMEOUT;
    
    CYBLE_API_RESULT_T              bleApiResult;
    CYBLE_GATTC_WRITE_CMD_REQ_T     uartTxDataWriteCmd;
    
    uartTxDataLength = 1;
    
    #ifdef FLOW_CONTROL
        if(uartTxDataLength >= (UART_UART_RX_BUFFER_SIZE - (UART_UART_RX_BUFFER_SIZE/2)))
        {
            DisableUartRxInt();
        }
        else
        {
            EnableUartRxInt();
        }
    #endif
    
    if((uartTxDataLength != 0))
    {
        if(uartTxDataLength >= (mtuSize))
        {
            uartIdleCount       = UART_IDLE_TIMEOUT;
            uartTxDataLength    = mtuSize;
        }
        else
        {
            if(--uartIdleCount == 0)
            {
                /*uartTxDataLength remains unchanged */;
            }
            else
            {
                uartTxDataLength = 0;
            }
        }
        
        if(0 != uartTxDataLength)
        {
            uartIdleCount       = UART_IDLE_TIMEOUT;

                    for(k=0;k<30;k++)
                    {
                        uartTxDataWriteCmd.value.len  = (uint32)20;
                        uartTxDataWriteCmd.attrHandle = rxCharHandle;
                        uartTxDataWriteCmd.value.val  = "" ;break;
                        do
                        {
                            bleApiResult = CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &uartTxDataWriteCmd);
                            CyBle_ProcessEvents();
                        }
                        while((CYBLE_ERROR_OK != bleApiResult) && (CYBLE_STATE_CONNECTED == cyBle_state));
                        //CyDelay(10);
                    }         
            
          //  #ifdef FLOW_CONTROL
           //     DisableUartRxInt();
          //  #endif
            
//            do
//            {
                bleApiResult = CyBle_GattcWriteWithoutResponse(cyBle_connHandle, &uartTxDataWriteCmd);
                CyBle_ProcessEvents();
//            }
 //           while((CYBLE_ERROR_OK != bleApiResult) && (CYBLE_STATE_CONNECTED == cyBle_state));
            
        }
    }
}

/*****************************************************************************************
* Function Name: DisableUartRxInt
******************************************************************************************
*
* Summary:
*  This function disables the UART RX interrupt.
*
* Parameters:
*   None.
*
* Return:
*   None.
*
*****************************************************************************************/
void DisableUartRxInt(void)
{
    UART_INTR_RX_MASK_REG &= ~UART_RX_INTR_MASK;  
}

/*****************************************************************************************
* Function Name: EnableUartRxInt
******************************************************************************************
*
* Summary:
*  This function enables the UART RX interrupt.
*
* Parameters:
*   None.
*
* Return:
*   None.
*
*****************************************************************************************/
void EnableUartRxInt(void)
{
    UART_INTR_RX_MASK_REG |= UART_RX_INTR_MASK;  
}

/* [] END OF FILE */
